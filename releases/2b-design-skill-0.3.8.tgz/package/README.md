# 2B-Design — Product Designer to Governed UI

> 面向 designer / product designer 的 B 端新产品设计 Skill：从产品方案、
> 页面 IA、视觉 token，到使用 Design-anchor 默认组件库生成一致 UI。

## 这是什么

2B-Design 是一份给 Claude / Codex / Cursor / Qoder / ChatGPT 等 AI 工具读的
指令包。它帮助产品设计师把一个新产品想法变成可实施的 B 端界面设计包，并把实现过程
接入 Design-anchor 的默认组件库、tokens、component specs、MCP 和 audit。

主路径是**新产品 / 新项目**：

```
Project mode → Concept → Roadmap → Feature specs → Page IA + component map
→ Theme tokens → Governed build → Design review → Project Health
```

推荐路径是**使用 Design-anchor 默认组件库**。如果用户已经有旧项目或成熟组件库，则只支持
上传 / 导入 React + Tailwind `.tsx` 组件库，再通过 Project Health 做迁移治理。

## 为什么存在

市面上很多设计 skill 擅长一次性生成漂亮页面，但弱点是：

1. 产品方案不够细，AI 只能猜；
2. 页面生成后组件、圆角、颜色、间距会漂；
3. 后续多轮生码无法保证一致性；
4. B 端产品长期维护时没有健康度反馈。

2B-Design 的分工是：

- 前半段：帮产品设计师把产品、功能、页面、状态和视觉方向想清楚；
- 后半段：把页面绑定到 Design-anchor 默认组件库和 token 协议；
- 生成后：回到 Project Health 看组件采用、token 状态、AI 规则新鲜度和迁移 backlog。

## 生命周期

| Stage | 产物 | 价值 |
|---|---|---|
| 0 Project Mode | `anchor-project-mode.md` | 新项目默认组件库；旧项目导入组件库 |
| 1 Concept | `concept.md` | 明确用户、场景、痛点和价值 |
| 2 Plan | `roadmap.md` | MVP / V1 / V2+ |
| 3 Feature | `features/*.md` | AI 可实现、QA 可验证 |
| 4 Page IA | `pages/*.md` | 页面结构 + Anchor Component Map |
| 5 Theme | `anchor-theme-decision.md` | preset / token / density / radius / motion |
| 6 Build | `implementation-brief.md` | 用默认组件库生成受治理 UI |
| 7 Review | `design-review.md` | 设计一致性与可用性检查 |
| 8 Health | Project Health | 长期组件/token/AI 规则治理 |

## 安装

### Claude Code

```bash
mkdir -p ~/.claude/skills/
git clone https://github.com/<your-org>/2b-design-skill ~/.claude/skills/2b-design
```

### Cursor

```bash
mkdir -p ~/.cursor/skills/
git clone https://github.com/<your-org>/2b-design-skill ~/.cursor/skills/2b-design
```

### OpenAI Codex CLI / Qoder / 其他通用 AI 工具

把 `AGENTS.md` 内容塞到工具的系统指令位置。Codex / Qoder 这类工具通常可以直接读取
项目或全局的 agent instruction。

### ChatGPT / Claude.ai web

复制 `system-prompt.md` 内容到对话开头。

## 使用方式

新产品：

```text
我想做一个 B 端客户提案管理工具，帮我从产品方案到页面设计完整梳理，并用 Design-anchor 默认组件库约束后续生成。
```

已有项目 / 自有组件库：

```text
我有一个 React + Tailwind 组件库，想导入后迁移到 Design-anchor 治理。
```

## 调用 Design-anchor npm 工具

2B-Design 不只输出 prompt。进入风格选择、生码、审计或 Project Health 时，它会引导
AI 工具调用 `design-anchor` npm 包：

```bash
# 首次使用，自动从 npm 下载并启动 Portal
npx --yes design-anchor@latest start

# 如果项目已经安装 design-anchor，则优先用本地版本
npx design-anchor start

# 只想把 Design-anchor 作为组件库装进项目时，先确认，再安装
npm install -D design-anchor@latest
npx design-anchor init

# 生码后治理检查
npx design-anchor audit
```

自动修复或写入项目依赖前，必须先让用户确认。

## 内置 Vibe Preset

| Preset | 性格 | 适合 |
|---|---|---|
| `linear` | 紧凑、锐利、工具感 | dev tools / 内部控制台 |
| `vercel-geist` | 极简、黑白、克制 | landing / 文档 / API 产品 |
| `stripe` | 专业、宽松、商务 | 金融 / API / B2B SaaS |
| `web3-dark` | 暗色、橙金、技术金融感 | Web3 / DeFi / wallet / crypto analytics |
| `minimal-dark` | 暗色、琥珀、安静高级感 | dev tools / AI workspace / focused SaaS |
| `saas-style-01` | 现代、克制、蓝色高识别度 | PLG SaaS / onboarding / dashboard |
| `saas-dark-02` | 暗色、强排版、锋利编辑感 | bold SaaS / developer tools / manifesto landing |
| `google-style` | 友好、圆润、Material You 感 | onboarding / 设置 / 平台型产品 |
| `hud-dark-style` | 暗色、高对比、几何仪表盘感 | analytics / command center / premium dashboard |
| `luxury-style` | 奢华、克制、杂志编辑感 | premium brand / executive portal / editorial SaaS |
| `notion-soft` | 温和、内容优先 | 知识库 / 内容协作 |
| `brutalist` | 强烈、硬朗、反主流 | indie / 文化品牌 |
| `glass` | 半透、圆润、移动优先 | 消费 / premium mobile |

Preset 会写入 Design-anchor token seeds，并生成 `.cursor/rules/anchor-style.mdc`，
让后续 AI 生码继续遵守同一视觉方向。

默认不是让用户凭感觉挑风格，而是从上一阶段 PRD 产物中自动路由：

- 读取 `concept.md`、`roadmap.md`、`features/*.md`、`pages/*.md`；
- 根据产品领域、用户角色、工作流密度、信任预期、品牌性格和页面组合推荐 preset；
- 高置信度时直接选择并写入 `anchor-theme-decision.md`；
- 置信度不足或用户想视觉选择时，运行 `npx --yes design-anchor@latest start` 唤起 Portal，
  让用户在 Theme / preset selection 中确认；
- preset 确认后不停止在风格讨论，继续应用 tokens + style rules，并进入 Stage 6
  Governed Build 生码。

Preset 使用双模式：

- intro mode：首页、landing、onboarding、pricing、docs showcase 可以使用原 prompt
  的完整视觉效果。
- product mode：功能页、治理页、后台、表格、表单、dashboard 使用同一套 token 和组件，
  但降低装饰和复杂动效。

即使是 intro mode，颜色、间距、圆角、字体、阴影、动效角色等可 token 化内容也必须走
Design-anchor tokens 或命名组件变体，避免首页和产品内页割裂。

## 与 Design-anchor 的深度融合

```
2B-Design
  ├─ 产品方案细化
  ├─ 页面 IA
  ├─ Anchor Component Map
  ├─ Theme / token decision
  └─ Implementation brief
        ↓
Design-anchor
  ├─ 默认组件库
  ├─ token 派生引擎
  ├─ component specs
  ├─ AI rules / MCP
  ├─ anchor audit
  └─ Project Health
```

新项目默认使用 Design-anchor 默认组件库。已有项目可以导入旧组件库，但会被视为迁移路径，
需要通过 Project Health 观察组件采用和治理 backlog。

## FAQ

**Q: 它是给工程师还是设计师？**  
A: 主要给 designer / product designer。工程师会受益于它产出的 implementation brief
和 Design-anchor 约束。

**Q: 它会直接写代码吗？**  
A: 如果当前 AI 工具有文件权限且用户明确要求，可以进入 Governed Build；否则输出
implementation brief 给 Cursor / Claude Code / Codex / Qoder 执行。

**Q: 默认推荐旧组件库导入吗？**  
A: 不。新项目推荐 Design-anchor 默认组件库。自有组件库导入只支持 React + Tailwind
`.tsx` 组件库，是已有项目迁移能力。

**Q: 生成后怎么保证不漂？**  
A: 通过 Design-anchor 的默认组件库、token、spec、AI rules、MCP、`anchor audit` 和
Project Health 闭环。

## 版本

- v0.3.8 — 增加 Design-anchor npm 工具调用协议：AI 工具会在 Portal、init、sync、audit、Project Health 阶段下载/调用 `design-anchor`。
- v0.3.7 — 新增 `Minimal Dark` preset；补充 PRD-driven preset routing、Portal 选择兜底、intro/product 双模式与首页 token 一致性规则。
- v0.3.6 — 新增 `Web3 Dark` preset，改造成 Design-anchor token/component-first 风格 prompt。
- v0.3.5 — 新增 `Saas Dark 02` preset，改造成 Design-anchor token/component-first 风格 prompt。
- v0.3.4 — 新增 `Luxury Style` preset，改造成 Design-anchor token/component-first 风格 prompt。
- v0.3.3 — 新增 `HUD Dark Style` preset，改造成 Design-anchor token/component-first 风格 prompt。
- v0.3.2 — 新增 `Google Style` preset，改造成 Design-anchor token/component-first 风格 prompt。
- v0.3.1 — 新增 `SaaS Style 01` preset，改造成 Design-anchor token/component-first 风格 prompt。
- v0.3.0 — Product Designer → Governed UI lifecycle；默认组件库推荐路径；新增 review / health loop。
- v0.2.0 — 5-stage pipeline + 6 vibe preset。
- v0.1.0 — lifecycle backbone draft。
